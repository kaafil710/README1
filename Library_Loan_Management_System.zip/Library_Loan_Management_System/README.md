# Library Loan Management System

## Description
This project is a JDBC-based Library Loan Management System developed using Java and Apache Derby Database. The application demonstrates transaction management, ACID properties, JDBC performance benchmarking, and database operations. The system supports member management, book management, loan processing, return processing, and performance evaluation using different JDBC strategies.

## Features
- Add Members
- Add Books
- View Books
- Process Loan Transactions
- Return Books
- Commit and Rollback Operations
- Savepoints
- JDBC PreparedStatement Usage
- Performance Benchmarking
- Database Indexing
- Exception Handling
- Menu Driven Console Interface

## Technologies Used
- Java
- JDBC
- Apache Derby Database
- Eclipse IDE

## Database
Embedded Apache Derby Database

JDBC URL:
jdbc:derby:lab10db;create=true

## Packages and Components

### connection
Handles database connection management and database initialization.

### business
Contains business logic for member and book operations.

### transaction
Implements transaction management including commit, rollback, and savepoint operations.

### benchmark
Contains performance benchmarking utilities for JDBC performance evaluation.

### ui
Contains the main console application and menu-driven interface.

### model
Contains model classes for Member, Book, and Loan entities.

## Functionalities

### Member Operations
- Add new members
- Prevent duplicate email entries

### Book Operations
- Add new books
- View available books
- Prevent duplicate ISBN entries

### Loan Operations
- Process book loans
- Return borrowed books
- Update book availability
- Update active loan counts

### Transaction Management
- Explicit transaction handling
- Auto-commit disabled during transactions
- Rollback on failure
- Savepoint implementation

### Performance Evaluation
- Individual Insert Benchmark
- Batch Insert Benchmark
- Statement vs PreparedStatement comparison

## Benchmark Observations
- Batch processing performs faster than individual inserts.
- PreparedStatement performs better than Statement.
- JDBC batching reduces database communication overhead.
- Indexed queries improve retrieval performance.

## How to Run the Project

1. Open the project in Eclipse IDE.
2. Ensure Java 17 is configured.
3. Add Apache Derby JAR files to the build path.
4. Run MainApp.java as Java Application.
5. Use the menu options to interact with the system.

## Author
Priyam Swain