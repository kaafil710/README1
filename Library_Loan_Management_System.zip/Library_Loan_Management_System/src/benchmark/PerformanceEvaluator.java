package benchmark;

import connection.ConnectionManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

public class PerformanceEvaluator {

    public static void individualInsertBenchmark(int count) {

        long startTime;
        long endTime;

        try (Connection conn =
                     ConnectionManager.getConnection()) {

            String query =
                    "INSERT INTO Books(Title, Author, ISBN, Available) " +
                    "VALUES(?,?,?,TRUE)";

            startTime = System.nanoTime();

            for (int i = 1; i <= count; i++) {

                PreparedStatement ps =
                        conn.prepareStatement(query);

                ps.setString(1, "Book" + i);
                ps.setString(2, "Author" + i);
                ps.setString(3, "ISBN-IND-" + i);

                ps.executeUpdate();
            }

            endTime = System.nanoTime();

            double timeMs =
                    (endTime - startTime) / 1000000.0;

            System.out.println(
                    "\nIndividual Insert Time: "
                    + timeMs + " ms");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void batchInsertBenchmark(int count) {

        long startTime;
        long endTime;

        try (Connection conn =
                     ConnectionManager.getConnection()) {

            conn.setAutoCommit(false);

            String query =
                    "INSERT INTO Books(Title, Author, ISBN, Available) " +
                    "VALUES(?,?,?,TRUE)";

            PreparedStatement ps =
                    conn.prepareStatement(query);

            startTime = System.nanoTime();

            for (int i = 1; i <= count; i++) {

                ps.setString(1, "BatchBook" + i);
                ps.setString(2, "BatchAuthor" + i);
                ps.setString(3, "ISBN-BATCH-" + i);

                ps.addBatch();
            }

            ps.executeBatch();

            conn.commit();

            endTime = System.nanoTime();

            double timeMs =
                    (endTime - startTime) / 1000000.0;

            System.out.println(
                    "\nBatch Insert Time: "
                    + timeMs + " ms");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void statementVsPreparedStatement() {

        try (Connection conn =
                     ConnectionManager.getConnection()) {

            Statement stmt =
                    conn.createStatement();

            long start1 =
                    System.nanoTime();

            stmt.executeUpdate(
                    "INSERT INTO Members(Name, Email, ActiveLoans) " +
                    "VALUES('Test1','test1@gmail.com',0)"
            );

            long end1 =
                    System.nanoTime();

            PreparedStatement ps =
                    conn.prepareStatement(
                            "INSERT INTO Members(Name, Email, ActiveLoans) " +
                            "VALUES(?,?,0)"
                    );

            long start2 =
                    System.nanoTime();

            ps.setString(1, "Test2");
            ps.setString(2, "test2@gmail.com");

            ps.executeUpdate();

            long end2 =
                    System.nanoTime();

            double stmtTime =
                    (end1 - start1) / 1000000.0;

            double psTime =
                    (end2 - start2) / 1000000.0;

            System.out.println(
                    "\nStatement Time: "
                    + stmtTime + " ms");

            System.out.println(
                    "PreparedStatement Time: "
                    + psTime + " ms");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}