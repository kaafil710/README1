package ui;

import benchmark.PerformanceEvaluator;
import business.BusinessLogic;
import connection.ConnectionManager;
import transaction.TransactionService;

import java.util.Scanner;

public class MainApp {

    public static void main(String[] args) {

        ConnectionManager.initializeDatabase();

        Scanner sc = new Scanner(System.in);

        while (true) {

            System.out.println("\n===== LIBRARY MENU =====");
            System.out.println("1. Add Member");
            System.out.println("2. Add Book");
            System.out.println("3. View Books");
            System.out.println("4. Process Loan");
            System.out.println("5. Return Book");
            System.out.println("6. Individual Insert Benchmark");
            System.out.println("7. Batch Insert Benchmark");
            System.out.println("8. Statement vs PreparedStatement");
            System.out.println("9. Exit");

            System.out.print("Enter Choice: ");

            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {

                case 1:

                    System.out.print("Enter Member Name: ");
                    String name = sc.nextLine();

                    System.out.print("Enter Email: ");
                    String email = sc.nextLine();

                    BusinessLogic.addMember(name, email);

                    break;

                case 2:

                    System.out.print("Enter Book Title: ");
                    String title = sc.nextLine();

                    System.out.print("Enter Author: ");
                    String author = sc.nextLine();

                    System.out.print("Enter ISBN: ");
                    String isbn = sc.nextLine();

                    BusinessLogic.addBook(title, author, isbn);

                    break;

                case 3:

                    BusinessLogic.viewBooks();

                    break;

                case 4:

                    System.out.print("Enter Member ID: ");
                    int memberId = sc.nextInt();

                    System.out.print("Enter Book ID: ");
                    int bookId = sc.nextInt();

                    TransactionService.processLoan(
                            memberId,
                            bookId
                    );

                    break;

                case 5:

                    System.out.print("Enter Member ID: ");
                    int returnMemberId = sc.nextInt();

                    System.out.print("Enter Book ID: ");
                    int returnBookId = sc.nextInt();

                    TransactionService.returnBook(
                            returnBookId,
                            returnMemberId
                    );

                    break;

                case 6:

                    PerformanceEvaluator
                            .individualInsertBenchmark(100);

                    break;

                case 7:

                    PerformanceEvaluator
                            .batchInsertBenchmark(100);

                    break;

                case 8:

                    PerformanceEvaluator
                            .statementVsPreparedStatement();

                    break;

                case 9:

                    ConnectionManager.shutdown();

                    System.out.println("Application Closed");

                    System.exit(0);

                    break;

                default:

                    System.out.println("Invalid Choice");
            }
        }
    }
}