package transaction;

import connection.ConnectionManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Savepoint;

public class TransactionService {

    public static void processLoan(int memberId,
                                   int bookId) {

        Connection conn = null;

        try {

            conn = ConnectionManager.getConnection();

            conn.setAutoCommit(false);

            String checkBook =
                    "SELECT Available FROM Books WHERE BookID=?";

            PreparedStatement checkStmt =
                    conn.prepareStatement(checkBook);

            checkStmt.setInt(1, bookId);

            ResultSet rs = checkStmt.executeQuery();

            if (rs.next()) {

                boolean available =
                        rs.getBoolean("Available");

                if (!available) {

                    System.out.println("Book Not Available");

                    conn.rollback();

                    return;
                }
            }

            Savepoint savepoint =
                    conn.setSavepoint("BeforeLoanInsert");

            String insertLoan =
                    "INSERT INTO Loans(MemberID, BookID, LoanDate) " +
                    "VALUES(?,?,CURRENT_DATE)";

            PreparedStatement loanStmt =
                    conn.prepareStatement(insertLoan);

            loanStmt.setInt(1, memberId);
            loanStmt.setInt(2, bookId);

            loanStmt.executeUpdate();

            String updateBook =
                    "UPDATE Books SET Available=FALSE " +
                    "WHERE BookID=?";

            PreparedStatement bookStmt =
                    conn.prepareStatement(updateBook);

            bookStmt.setInt(1, bookId);

            bookStmt.executeUpdate();

            String updateMember =
                    "UPDATE Members SET ActiveLoans = ActiveLoans + 1 " +
                    "WHERE MemberID=?";

            PreparedStatement memberStmt =
                    conn.prepareStatement(updateMember);

            memberStmt.setInt(1, memberId);

            int rows = memberStmt.executeUpdate();

            if (rows == 0) {

                conn.rollback(savepoint);

                System.out.println("Member Update Failed");

                return;
            }

            conn.commit();

            System.out.println("Loan Processed Successfully");

        } catch (Exception e) {

            try {

                if (conn != null) {

                    conn.rollback();

                    System.out.println("Transaction Rolled Back");
                }

            } catch (Exception ex) {
                ex.printStackTrace();
            }

            e.printStackTrace();

        } finally {

            try {

                if (conn != null) {

                    conn.setAutoCommit(true);

                    conn.close();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static void returnBook(int bookId,
                                  int memberId) {

        Connection conn = null;

        try {

            conn = ConnectionManager.getConnection();

            conn.setAutoCommit(false);

            String updateBook =
                    "UPDATE Books SET Available=TRUE " +
                    "WHERE BookID=?";

            PreparedStatement bookStmt =
                    conn.prepareStatement(updateBook);

            bookStmt.setInt(1, bookId);

            bookStmt.executeUpdate();

            String updateLoan =
                    "UPDATE Loans SET ReturnDate=CURRENT_DATE " +
                    "WHERE BookID=? AND MemberID=? " +
                    "AND ReturnDate IS NULL";

            PreparedStatement loanStmt =
                    conn.prepareStatement(updateLoan);

            loanStmt.setInt(1, bookId);
            loanStmt.setInt(2, memberId);

            loanStmt.executeUpdate();

            String updateMember =
                    "UPDATE Members SET ActiveLoans = ActiveLoans - 1 " +
                    "WHERE MemberID=?";

            PreparedStatement memberStmt =
                    conn.prepareStatement(updateMember);

            memberStmt.setInt(1, memberId);

            memberStmt.executeUpdate();

            conn.commit();

            System.out.println("Book Returned Successfully");

        } catch (Exception e) {

            try {

                if (conn != null) {

                    conn.rollback();

                    System.out.println(
                            "Return Transaction Rolled Back");
                }

            } catch (Exception ex) {
                ex.printStackTrace();
            }

            e.printStackTrace();

        } finally {

            try {

                if (conn != null) {

                    conn.setAutoCommit(true);

                    conn.close();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}