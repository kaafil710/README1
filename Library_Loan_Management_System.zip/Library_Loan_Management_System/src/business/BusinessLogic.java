package business;

import connection.ConnectionManager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BusinessLogic {

    public static void addMember(String name, String email) {

        String query =
                "INSERT INTO Members(Name, Email, ActiveLoans) VALUES(?,?,0)";

        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, name);
            ps.setString(2, email);

            int rows = ps.executeUpdate();

            if (rows > 0) {

                System.out.println("Member Added Successfully");
            }

        } catch (SQLException e) {

            if (e.getSQLState().equals("23505")) {

                System.out.println("Email Already Exists");

            } else {

                e.printStackTrace();
            }
        }
    }

    public static void addBook(String title,
                               String author,
                               String isbn) {

        String query =
                "INSERT INTO Books(Title, Author, ISBN, Available) VALUES(?,?,?,TRUE)";

        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, title);
            ps.setString(2, author);
            ps.setString(3, isbn);

            int rows = ps.executeUpdate();

            if (rows > 0) {

                System.out.println("Book Added Successfully");
            }

        } catch (SQLException e) {

            if (e.getSQLState().equals("23505")) {

                System.out.println("Duplicate ISBN Not Allowed");

            } else {

                e.printStackTrace();
            }
        }
    }

    public static void viewBooks() {

        String query = "SELECT * FROM Books";

        try (Connection conn = ConnectionManager.getConnection();
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            System.out.println("\n===== BOOK LIST =====");

            while (rs.next()) {

                System.out.println(
                        "Book ID: " + rs.getInt("BookID") +
                        " | Title: " + rs.getString("Title") +
                        " | Author: " + rs.getString("Author") +
                        " | Available: " + rs.getBoolean("Available")
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}