package connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class ConnectionManager {

    private static final String URL =
            "jdbc:derby:lab10db;create=true";

    private static final String DRIVER =
            "org.apache.derby.jdbc.EmbeddedDriver";

    public static Connection getConnection() {

        Connection conn = null;

        try {

            Class.forName(DRIVER);

            conn = DriverManager.getConnection(URL);

            System.out.println("Database Connected Successfully");

        } catch (Exception e) {
            e.printStackTrace();
        }

        return conn;
    }

    public static void initializeDatabase() {

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {

            String createMembersTable =
                    "CREATE TABLE Members (" +
                    "MemberID INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY, " +
                    "Name VARCHAR(100), " +
                    "Email VARCHAR(100) UNIQUE, " +
                    "ActiveLoans INT DEFAULT 0" +
                    ")";

            String createBooksTable =
                    "CREATE TABLE Books (" +
                    "BookID INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY, " +
                    "Title VARCHAR(200), " +
                    "Author VARCHAR(100), " +
                    "ISBN VARCHAR(30) UNIQUE, " +
                    "Available BOOLEAN DEFAULT TRUE" +
                    ")";

            String createLoansTable =
                    "CREATE TABLE Loans (" +
                    "LoanID INT PRIMARY KEY GENERATED ALWAYS AS IDENTITY, " +
                    "MemberID INT, " +
                    "BookID INT, " +
                    "LoanDate DATE, " +
                    "ReturnDate DATE, " +
                    "FOREIGN KEY (MemberID) REFERENCES Members(MemberID), " +
                    "FOREIGN KEY (BookID) REFERENCES Books(BookID)" +
                    ")";

            stmt.executeUpdate(createMembersTable);
            stmt.executeUpdate(createBooksTable);
            stmt.executeUpdate(createLoansTable);

            String createISBNIndex =
                    "CREATE INDEX idx_isbn ON Books(ISBN)";

            String createMemberIndex =
                    "CREATE INDEX idx_member ON Loans(MemberID)";

            String createReturnDateIndex =
                    "CREATE INDEX idx_return ON Loans(ReturnDate)";

            stmt.executeUpdate(createISBNIndex);
            stmt.executeUpdate(createMemberIndex);
            stmt.executeUpdate(createReturnDateIndex);

            System.out.println("Tables and Indexes Created Successfully");

        } catch (SQLException e) {

            if (e.getSQLState().equals("X0Y32")) {

                System.out.println("Tables already exist");

            } else {

                e.printStackTrace();
            }
        }
    }

    public static void shutdown() {

        try {

            DriverManager.getConnection(
                    "jdbc:derby:;shutdown=true");

        } catch (SQLException e) {

            System.out.println("Derby Shutdown Successfully");
        }
    }
}